
from scipy.spatial.distance import squareform
from GPy.plotting import Tango
from matplotlib import pyplot as plt
import itertools, numpy as np, seaborn as sns, networkx as nx

from scipy.spatial.distance import squareform, pdist

def plot_simulation_results_preliminary(results):
    fig = plt.figure(figsize=(17,4))
    _tmp = results.unstack(level=(0, 2))
    _m = _tmp.mean().unstack(level=(1,2))
    _s = _tmp.std().unstack(level=(1,2))

    g = plt.GridSpec(8,5)
    legend = fig.add_subplot(g[:1,:])
    legend.set_frame_on(False)
    legend.xaxis.set_visible(False)
    legend.yaxis.set_visible(False)

    axes = []
    first = None
    for i in range(5):
        if first is None:
            first = _nx = fig.add_subplot(g[1:, i])
        else:
            _nx = fig.add_subplot(g[1:, i], sharey=first)
        axes.append(_nx)

    fig.subplots_adjust(wspace=.05)
    [plt.setp(_nx.get_yticklabels(), visible=False) for _nx in axes[1:]]

    axit = iter(axes)

    for n, t in _m.groupby(axis=1, level=0):
        ax = next(axit)
        np.abs(_m[n]).plot(kind='bar', yerr=_s[n], ax=ax, width=.85, legend=False, rot=17)
        ax.grid(b='off')
        ax.yaxis.grid(b='on')
        ax.set_title('SLS{}'.format(n))
        # ax.text(.04, .96, 'dataset {}'.format(n), va='top', transform=ax.transAxes)
        #ax.set_ylim(0.,1.)

    #first.set_ylim(0,0.4)
    legend.legend(*ax.get_legend_handles_labels(), ncol=6, mode="expand", borderaxespad=0.)
    fig.tight_layout()
    return fig, first

def plot_dist_hist(M, ax):
    d_m = M[:,None]-M[None, :]
    D = np.einsum('ijq,ijq->ij',d_m,d_m)
    _ = ax.hist(squareform(D), bins=200)

def plot_comparison(m, pt, X_init, dims, labels, ulabels, cmap='magma', cmap_index=None):
    fig = plt.figure(figsize=(10,5))
    gs = plt.GridSpec(7,3)

    #Tango.reset()

    #label_pos, col, mi, ma = _get_label_pos(X, pt, labels, ulabels)
    #colors = _get_colors(cmap, col, mi, ma, cmap_index)
    #marker = dict([(lab, c) for lab,c in zip(ulabels, itertools.cycle('<>^vsd'))])

    axes = np.empty((2,3), object)

    for r in range(2):
        for c in range(3):
            axes[r,c] = fig.add_subplot(gs[1+(r*3):1+((r+1)*3), c])#, sharex=axes[r-1,c], sharey=axes[r,c-1])
            plt.setp(axes[r,c].get_xticklabels(), visible=False)
            plt.setp(axes[r,c].get_yticklabels(), visible=False)
            #if r==0:
            #    plt.setp(axes[r,c].get_xticklabels(), visible=False)
            #if c!=0:
            #    plt.setp(axes[r,c].get_yticklabels(), visible=False)


    axit = axes.flat

    ax = next(axit)
    #try:
    #    msi = m.get_most_significant_input_dimensions()[:2]
    #except:
    #    msi = m.Y0.get_most_significant_input_dimensions()[:2]
    m.plot_magnification(labels=labels,
                         resolution=20,
                         scatter_kwargs=dict(s=40, lw=.1, edgecolor='w'),
                         ax=ax,
                         plot_scatter=False,
                        legend=False)
    X = m.X.mean[:, m.get_most_significant_input_dimensions()[:2]]

    plot_graph_nodes(X, pt, labels, ulabels, ax, cmap=cmap, cmap_index=cmap_index, box=True)
    #for lab in ulabels:
    #    x, y = X[lab==labels].T
    #    ax.scatter(x, y, c=colors[lab], marker=marker[lab], label=lab, lw=0.1, edgecolor='w', s=40)

    ax.set_xlabel('')
    ax.set_ylabel('')
    ax.text(0.01,.98,"cellSLAM",va='top',transform=ax.transAxes,color='w')

    i = 0
    for name in dims:
        ax = next(axit)
        X = X_init[:,dims[name]]
        plot_graph_nodes(X, pt, labels, ulabels, ax, cmap=cmap, cmap_index=cmap_index, box=True)
        ax.text(0.01,.98,name,va='top',transform=ax.transAxes)
        i += 2
    return fig, axes

def plot_time_graph(G, X, pseudo_time, labels, ulabels, begin, startoffset, fig, ax):
    plot_graph_nodes(X, pseudo_time, labels, ulabels, ax)

    ecols = [e[2]['weight'] for e in G.edges(data=True)]

    cmap = plt.cm.magma
    pos = dict([(i, x) for i, x in zip(range(X.shape[0]), X)])
    edges = nx.draw_networkx_edges(G, pos=pos, ax=ax, edge_color=ecols, edge_cmap=cmap, width=1)

    cbar = fig.colorbar(edges, ax=ax, pad=.01, fraction=.1, ticks=[], drawedges=False)
    cbar.ax.set_frame_on(False)
    cbar.solids.set_edgecolor("face")
    cbar.set_label('pseudo time')

    mi, ma = X.min(0), X.max(0)
    ax.set_xlim(mi[0], ma[0])
    ax.set_ylim(mi[1], ma[1])
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_frame_on(False)

    #ax.scatter(*X[start].T, edgecolor='red', lw=1.5, facecolor='none', s=50, label='start')
    ax.annotate('start', xy=X[begin].T, xycoords='data',
                    xytext=startoffset, textcoords='offset points',
                    size=9,
                    color='.4',
                    bbox=dict(boxstyle="round", fc="0.8", ec='1', pad=.01),
                    arrowprops=dict(arrowstyle="fancy",
                                    fc="0.6", ec="none",
                                    #patchB=el,
                                    connectionstyle="angle3,angleA=17,angleB=-90"),
                    )

    #ax.legend(bbox_to_anchor=(0., 1.02, 1.2, .102), loc=3,
    #           ncol=4, mode="expand", borderaxespad=0.)


def plot_graph_nodes(X, pt, labels, ulabels, ax, cmap='magma', cmap_index=None, box=True, text_kwargs=None, scatter=True, **scatter_kwargs):
    #Tango = GPy.plotting.Tango
    #Tango.reset()
    marker = itertools.cycle('<>sd^')
    label_pos, col, mi, ma = _get_label_pos(X, pt, labels, ulabels)
    colors = _get_colors(cmap, col, mi, ma, cmap_index)

    for l in ulabels:
        #c = Tango.nextMedium()
        c, r = colors[l]
        fil = (labels==l)
        if scatter:
            ax.scatter(*X[fil].T, linewidth=.1, facecolor=c, alpha=.8, edgecolor='w', marker=next(marker), label=None)

        p = label_pos[l]
        rgbc = c#[_c/255. for _c in Tango.hex2rgb(c)]
        if r <.5:
            ec = 'w'
        else:
            ec = 'k'
        if box:
            fc = list(rgbc)
            #fc[-1] = .7
            props = dict(boxstyle='round', facecolor=fc, alpha=0.8, edgecolor=ec)
        else:
            props = dict()
        ax.text(p[0], p[1], l, alpha=.9, ha='center', va='center', color=ec, bbox=props, **text_kwargs or {})

def _get_colors(cmap, col, mi, ma, cmap_index):
    if cmap_index is None:
        cmap = plt.cm.get_cmap(cmap)
        colors = dict([(l, (cmap((col[l]-mi)/(ma-mi)), (col[l]-mi)/(ma-mi))) for l in col])
    else:
        cmap = sns.color_palette(cmap, len(col))[cmap_index]
        r = np.linspace(0,1,len(col))[cmap_index]
        colors = dict([(l, (cmap, r)) for l in col])
    return colors

def _get_sort_dict(labels, ulabels):
    sort_dict = {}#np.empty(labels.shape, dtype=int)
    curr_i = 0
    for i, l in enumerate(ulabels):
        hits = labels==l
        sort_dict[l] = np.where(hits)[0]
        curr_i += hits.sum()
    return sort_dict

def _get_label_pos(X, pt, labels, ulabels):
    sort_dict = _get_sort_dict(labels, ulabels)
    label_pos = {}
    col = {}
    mi, ma = np.inf, 0
    for l in ulabels:
        label_pos[l] = X[sort_dict[l]].mean(0)
        c = pt[sort_dict[l]].mean()
        col[l] = c
        mi = min(mi, c)
        ma = max(ma, c)
    return label_pos, col, mi, ma