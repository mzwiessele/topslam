from __future__ import print_function
import numpy as np, pandas as pd
from matplotlib import pyplot as plt
from sklearn.manifold import TSNE, SpectralEmbedding, Isomap
from sklearn.decomposition import FastICA, PCA
from cellSLAM import ManifoldCorrectionTree
from compute_errors import add_errors
from scipy import sparse
from scipy.sparse.csgraph import minimum_spanning_tree, dijkstra
from scipy.stats import linregress
import os
from plot_definitions_datasets import plot_comparison

methods = {'t-SNE':TSNE(n_components=2),
           'PCA':PCA(n_components=2),
           'Spectral': SpectralEmbedding(n_components=2, n_neighbors=10),
           'Isomap': Isomap(n_components=2, n_neighbors=10),
           'ICA': FastICA(n_components=2)
           }

# The seeds used for the different datasets,
# These are chosen to be non overlapping latent spaces,
# as the generation of the trajectories is random
# and can involve overlapping time lines
# by visual inspection we chose those five:
seeds = [8971, 3551, 3279, 5001, 5081]

_verbose = False

def nearest_neighbor_graph(D, k):
    idxs = np.argsort(D)
    r = range(D.shape[0])
    idx = idxs[:, :k]
    _distances = sparse.lil_matrix(D.shape)
    for neighbours in idx.T:
        _distances[r, neighbours] = D[r, neighbours]
    return _distances

def extract_manifold_distances_mst(D):
    # First do the minimal spanning tree distances
    if _verbose: print("    Tree...")
    mst = minimum_spanning_tree(D)
    return dijkstra(mst, directed=False, return_predecessors=False), mst

def extract_manifold_distances_knn(D, knn=[3,4,5,7,10], add_mst=None):
    # K Nearest Neighbours distances
    idxs = np.argsort(D)
    r = range(D.shape[0])
    for k in knn:
        if _verbose: print("    {} Nearest Neighbours...".format(k))
        idx = idxs[:, :k]
        _distances = sparse.lil_matrix(D.shape)
        for neighbours in idx.T:
            _distances[r, neighbours] = D[r, neighbours]
        if add_mst is not None:
            for i,j,v in zip(*sparse.find(add_mst)):
                if _distances[i,j] == 0:
                    _distances[i,j] = v
        nearest_neighbour_distances = dijkstra(_distances, directed=False)
        yield k, nearest_neighbour_distances

def run_methods_simulation(Y, methods, true_distances_=None, results_pd=None, true_time=None, time_results_pd=None, start=0):
    dims = {}
    i = 0
    for name in methods:
        method = methods[name]
        q = method.n_components
        dims[name] = slice(i, i+q)
        i += q
    latent_spaces = np.empty((Y.shape[0], i))

    if not isinstance(true_distances_, list):
        true_distances_ = [true_distances_]
    if not isinstance(results_pd, list):
        results_pd = [results_pd]

    for name in methods:
        if _verbose: print('  running {}...'.format(name))
        method = methods[name]
        try:
            _lat = method.fit_transform(Y)
            latent_spaces[:, dims[name]] = _lat
            _lat = _lat[:, None]-_lat[None, :]
            meth_distances = np.sqrt(np.einsum('ijq,ijq->ij', _lat, _lat))
            if (true_distances_[0] is not None) or (time_results_pd is not None):
                # tree distances:
                t_dist, mst = extract_manifold_distances_mst(meth_distances)
                for true_distances, res in zip(true_distances_, results_pd):
                    if res is not None:
                        add_errors(res, t_dist, true_distances, "{} Tree Corrected".format(name))
                # time
                if time_results_pd is not None:
                    lr = linregress(true_time, t_dist[start])
                    _subname = "{} Tree Corrected".format(name)
                    time_results_pd.loc['rvalue', _subname] = lr.rvalue
                    time_results_pd.loc['pvalue', _subname] = lr.pvalue
                    time_results_pd.loc['stderr', _subname] = lr.stderr

                # knn distances:
                for k, knn_dst in extract_manifold_distances_knn(meth_distances, add_mst=mst):
                    for true_distances, res in zip(true_distances_, results_pd):
                        if res is not None:
                            add_errors(res, knn_dst, true_distances, '{} {}N Corrected'.format(name, k))
                        # time
                    if time_results_pd is not None:
                        lr = linregress(true_time, knn_dst[start])
                        _subname = '{} {}N Corrected'.format(name, k)
                        time_results_pd.loc['rvalue', _subname] = lr.rvalue
                        time_results_pd.loc['pvalue', _subname] = lr.pvalue
                        time_results_pd.loc['stderr', _subname] = lr.stderr
        except:
            raise
            print("Error detected in running method, ignoring this method as NAN")
    latent_spaces -= latent_spaces.mean(0)
    latent_spaces /= latent_spaces.std(0)
    return latent_spaces, dims

def run_bgplvm_results(m, true_distances_=None, results_pd=None, true_time=None, time_results_pd=None, start=0, name='cellSLAM'):
    if m.kern.ARD:
        dimensions = (m.kern.input_sensitivity()>np.percentile(m.kern.input_sensitivity(), 50)).nonzero()[0]
    else:
        dimensions = range(m.kern.input_dim) # This is the no optimization case
    mc = ManifoldCorrectionTree(m, dimensions=dimensions)
    if not isinstance(true_distances_, list):
        true_distances_ = [true_distances_]
    if not isinstance(results_pd, list):
        results_pd = [results_pd]


    # Extract corrected distances from bgplvm result:
    meth_distances = mc.manifold_corrected_distance_matrix.toarray()

    if (true_distances_[0] is not None) or (time_results_pd is not None):
        # tree distances:
        t_dist, mst = extract_manifold_distances_mst(meth_distances)
        for true_distances, res in zip(true_distances_, results_pd):
            if res is not None:
                add_errors(res, t_dist, true_distances, "{} Tree Corrected".format(name))
        # time
        if time_results_pd is not None:
            lr = linregress(true_time, t_dist[start])
            _subname = "{} Tree Corrected".format(name)
            time_results_pd.loc['rvalue', _subname] = lr.rvalue
            time_results_pd.loc['pvalue', _subname] = lr.pvalue
            time_results_pd.loc['stderr', _subname] = lr.stderr

        # knn distances:
        for k, knn_dst in extract_manifold_distances_knn(meth_distances, add_mst=mst):
            for true_distances, res in zip(true_distances_, results_pd):
                if res is not None:
                    add_errors(res, knn_dst, true_distances, '{} {}N Corrected'.format(name, k))
                # time
            if time_results_pd is not None:
                lr = linregress(true_time, knn_dst[start])
                _subname = '{} {}N Corrected'.format(name, k)
                time_results_pd.loc['rvalue', _subname] = lr.rvalue
                time_results_pd.loc['pvalue', _subname] = lr.pvalue
                time_results_pd.loc['stderr', _subname] = lr.stderr

def collect_results(collection, key, n_repeats):
    results = pd.concat(collection, keys=[(i,j) for i in seeds for j in range(n_repeats)])
    test = results.copy()
    test.columns = pd.MultiIndex.from_tuples([name.split(" ", 1) for name in test.columns])
    test = test.reorder_levels([1,0], 1).stack().xs(key, level=2)
    test.index.names = ['latent space', 'data simulation', 'method']
    return test

def create_and_save_simulations(guo_simulation, safedir, n_repeats=10):
    from scipy import io
    for xiter in range(len(seeds)):
        seed = seeds[xiter]
        folder_path = os.path.join(safedir, '{}'.format(seed))
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)

        print("SLS{}...".format(seed))
        Xsim, simulate_new, t, c, labels, seed = guo_simulation(seed=seed)

        df = pd.DataFrame(Xsim)
        df['time'] = t

        a_dict = {col_name : df[col_name].values for col_name in df.columns.values}
        a_dict[df.index.name] = df.index.values
        io.savemat(os.path.join(folder_path, '{}_Xsim.mat'.format(seed)), {'struct':a_dict})
        df.to_csv(os.path.join(folder_path, '{}_Xsim.csv'.format(seed)))

        for datasim in range(n_repeats):
            print(' {}'.format(datasim), end='')
            np.random.seed(datasim)
            Y = simulate_new()

            df = pd.DataFrame(Y)
            df['labels'] = labels
            a_dict = {col_name : df[col_name].values for col_name in df.columns.values}
            io.savemat(os.path.join(folder_path, '{}_{}.mat'.format(seed, datasim)), {'struct':a_dict})
            df.to_csv(os.path.join(folder_path, '{}_{}.csv'.format(seed, datasim)))
        print ()

def run_results(run_bgplvm, guo_simulation, safedir, n_repeats=10, for_each_method=False):
    Xsim_results_collection = []
    time_results_collection = []
    runtime_collection = []
    ard_collection = []
    method_results_collection = []
    model_collection = []
    pt_collection = []

    import time
    # Some seeds for which we know the latent trajectory does not cross over:

    for xiter in range(len(seeds)):
        seed = seeds[xiter]
        folder_path = os.path.join(safedir, '{}'.format(seed))
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)

        print("SLS{}...".format(seed))
        Xsim, simulate_new, t, c, labels, seed = guo_simulation(seed=seed)
        ulabels = []
        for l in labels:
            if l not in ulabels:
                ulabels.append(l)
        ulabels = np.asarray(ulabels)

        if _verbose: print('  true manifold distances...')
        # Reconstruction errors along simulated manifold:
        true_manifold = Xsim
        _DT = true_manifold[:, None]-true_manifold[None, :]
        _DT = np.sqrt(np.einsum('ijq,ijq->ij', _DT, _DT))
        Xsim_distances, _ = extract_manifold_distances_mst(_DT)

        # Reconstruction errors of underlying time
        true_manifold = t
        _DT = true_manifold[:, None]-true_manifold[None, :]
        _DT = np.sqrt(np.einsum('ijq,ijq->ij', _DT, _DT))
        time_distances, _ = extract_manifold_distances_mst(_DT)

        true_distances = [Xsim_distances, time_distances]

        if not _verbose: print('  Iteration', end="")

        for datasim in range(n_repeats):
            if _verbose: print('  Iteration {}...'.format(datasim))
            else: print(' {}'.format(datasim), end='')
            np.random.seed(datasim)
            Y = simulate_new()

            if _verbose: print("  new save df...")
            res = [pd.DataFrame(), pd.DataFrame()]
            pt_result = pd.DataFrame()

            X_init, dims = run_methods_simulation(Y, methods, true_distances, res, t[:,0], pt_result, 0)
            method_results_collection.append(X_init.copy())

            if _verbose: print("  running bgplvm...")

            if not for_each_method:
                start = time.time()
                m = run_bgplvm(Y, X_init)
                runtime_collection.append(time.time()-start)

                if _verbose: print("    running bgplvm distance metrics...")
                run_bgplvm_results(m, true_distances, res, t[:,0], pt_result, 0)

                # ARD plot
                fig, ax = plt.subplots(figsize=(6,4))

                ard_res = pd.DataFrame(m.kern.input_sensitivity()[None,:], columns=pd.MultiIndex.from_product((methods.keys(), range(2))))
                ard_collection.append(ard_res)

                ard_res.stack(level=0).loc[0].plot(kind='bar', width=.85, ax=ax, rot=0)
                _ = ax.yaxis.set_ticklabels([])
                ax.set_ylabel('Relative [Arbitrary]')
                plt.savefig(os.path.join(folder_path, 'ARD_{}.pdf'.format(datasim)), transparent=True, bbox_inches='tight')

                # method_comparison plot
                plot_comparison(m, t, X_init, dims, labels, ulabels, cmap='magma', cmap_index=None)
                plt.savefig(os.path.join(folder_path, 'method_comparison_{}.pdf'.format(datasim)), transparent=True, bbox_inches='tight')
                plt.close('all')
            else:
                for method in methods:
                    start = time.time()
                    m = run_bgplvm(Y, X_init[:,dims[method]])
                    runtime_collection.append([seed, datasim, method, time.time()-start])

                    if _verbose: print("    running bgplvm distance metrics...")
                    run_bgplvm_results(m, true_distances, res, t[:,0], pt_result, 0, name='{}+cellSLAM'.format(method))

            if _verbose: print("")
            Xsim_results_collection.append(res[0])
            time_results_collection.append(res[1])
            pt_collection.append(pt_result)

        if not _verbose: print('')
    return Xsim_results_collection, time_results_collection, runtime_collection, ard_collection, method_results_collection, model_collection, pt_collection