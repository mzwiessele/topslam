import numpy as np

def _normalized_MSE(E,T):
    #===============================
    # Normalize test matrix E, so it 
    # is in the same range
    # as the target T. We are only 
    # interested in structural 
    # differences, as latent spaces
    # are scalable!
    E = (E/(np.nanmax(E)-np.nanmin(E)))*T.ptp() 
    #===============================
    Err = (E-T)
    SE = (Err**2)
    MSE = np.nanmean(SE)
    return E, T, MSE

def add_errors(res, E, T, name):
    E, T, MSE = _normalized_MSE(E, T)
    RMSE = np.sqrt(MSE)
    res.loc['NRMSE', name] = RMSE/(T.ptp())
    res.loc['CVRMSE', name] = RMSE/((T.mean()+E.mean())/2.)